#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include "stringhelp.h"
#include <string.h>
#include <ctype.h>
#include <assert.h>
#include "log4c.h"

int main(void)
{
    char errMsg[L4C_ERROR_MSG_MAX + 1] = { 0 };

    struct Log4cStruct log = l4cOpen("logW6.txt", 1);
    // I am putting 1 to keep a record instead of 0.

    if (l4cCheck(&log, errMsg))
    {
        printf("%s\n", errMsg);
    }
    else
    {
        // char testStr[] = { "This is a\n string with embedded newline character and \n12345 numbers inside it as well 67890" };
        char testStr[] = "This is a\n string with embedded newline character and \n12345 numbers inside it as well 67890";
        // professor in this I have remove the curly braces and keeping the double quotes.
        
        struct StringIndex index = indexString(testStr);
        int i;


        // these are the log for the lines. 
		//and we are also using if condition print our error message.
        l4cInfo(&log, "LINES");

        if (l4cCheck(&log, errMsg))
        {
            printf("%s\n", errMsg);
        }
        printf("LINES\n");

        // I am trying to initialize the empty string. 
        char printedOutput[1000] = "";

        for (i = 0; i < index.numLines; i++)
        {
            // printUntil(index.str, index.lineStarts[i], '\n');
            printUntil(index.str, index.lineStarts[i], '\0');
            // instead of \n I am using \0.
            printf("\n");

            strcat(printedOutput, index.str + index.lineStarts[i]);
            // this will concatenate the two string
        }

        //assertion for the lines
        assert(strcmp(printedOutput, testStr) == 0);

        // in the assertion for the lines, I am adding a string comparing where we are comparing
		// two string which is printedOutput and testStr and the comparison should be equal to 0

		// these are the log for WORDS.

		// I am doing the same log file method as we did for line
		// here, I have added the same if condition which was used earlier.
		// our error message will be printed with the provided if condition
        l4cInfo(&log, "WORDS");

        if (l4cCheck(&log, errMsg))
        {
            printf("%s\n", errMsg);
        }
        printf("\nWORDS\n");

        int matchFoundW = 0;
        // I am trying to initialize a flag outside the fo loop which is been created.

        for (i = 0; i < index.numWords; i++)
        {
            char printedWords[1000] = "";
            // Here I am trying to initialize a buffer which is temporary for the printed words.

            printUntilSpace(index.str, index.wordStarts[i]);
            printf("\n");

			//here I have made an int variable name predictedWordLength where I am using a string function
			// which is strcspn(), this is used for finding the character which present in string 1 and string 2
			// then I am using the printedWords and equating it with \0 value
			// I tried to use strcpy but it said too many argument passed so I tried then strncpy which worked.

            int predictedWordLength = strcspn(index.str + index.wordStarts[i], "\n");
            strncpy(printedWords, index.str + index.wordStarts[i], predictedWordLength);
            printedWords[predictedWordLength] = '\0';

            //I am defining the predicted words for comparison for the words.
            char* predictedWords[] = { "This", "is", "a", "string", "with", "embedded", "newline", "characters", "and", "numbers", "inside", "it", "as", "well" };
            int numPredictedWords = sizeof(predictedWords) / sizeof(predictedWords[0]);

            //I am now comparing the printed words with the each predicted words.
			// created a variable assigning value 0
            int matchFoundWords = 0;

            for (int j = 0; j < numPredictedWords; j++)
            {
                if (strcmp(printedWords, predictedWords[j]) == 0)
                {
                    matchFoundWords = 1;
                    break;
                }
            }

            matchFoundW |= matchFoundWords;
            // setting the matchFoundW to 1 if our matchFoundWords 1
        }

        assert(matchFoundW);
        //asserting that a match was found at least once


        // these are the logs for the numbers
        l4cInfo(&log, "NUMBERS");

        // as we did for the lines, words similarly we are doing it for the numbers as well
		// adding the if condition and printing the error message
        if (l4cCheck(&log, errMsg))
        {
            printf("%s\n", errMsg);
        }

        printf("\nNUMBERS\n");

        // initializing the matchFound variable and assigning it to 0.
        int matchFound = 0;

        for (i = 0; i < index.numNumbers; i++)
        {
            char printedNumber[1000] = "";
            // initializing the temporary buffer for the printed number.
            printUntilSpace(index.str, index.numberStarts[i]);
            printf("\n");

            // I would now try to extract the printed number from the string 
			// we are providing as an input.

			/*I have declare a variable predictedNumberLength with assigning a strcspn function and passing index.str and index.numStart[i]
			also in the next line I am comparing the these two strings and lastly I am setting the null character for printedNumber string*/

            int predictedNumberLength = strcspn(index.str + index.numberStarts[i], "\n");
            strncpy(printedNumber, index.str + index.numberStarts[i], predictedNumberLength);
            printedNumber[predictedNumberLength] = '\0';


            // defining the predicted numbers for the comparison for the numbers.
            char* predictedNumbers[] = { "12345", "67890" };
            int numPredictedNumbers = sizeof(predictedNumbers) / sizeof(predictedNumbers[0]);
            /*
				here I have declare two data types which are for predictedNumber and numPredictedNumbers
				the char data type store and holds the value we have which is 12345, 7890
				on the other hand we are dividing the sizes of predictedNumbers with predictedNumber[0] and
				storing that value in int data type variable which is numPredictNumbers.
			*/

			// comparing the printed number with every predicted Number.
            int currentMatch = 0;

            for (int k = 0; k < numPredictedNumbers; k++)
            {
                if (strcmp(printedNumber, predictedNumbers[k]) == 0)
                {
                    currentMatch = 1;
                    break;
                }
            }

            matchFound |= currentMatch;
            // Setting the matchFound to 1 if currentMatch is 1
        }
        // Asserting that the match was found at least once
        assert(matchFound);

        l4cClose(&log);
    }

    return 0;
}
